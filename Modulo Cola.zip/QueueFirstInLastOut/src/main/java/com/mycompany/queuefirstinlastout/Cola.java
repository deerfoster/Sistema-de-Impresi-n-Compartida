/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.queuefirstinlastout;

/**
 *
 * @author xaria
 */

// este es el modulo de la cola, tiene su entrada y salida // 

public class Cola {
    private TrabajoCola frente;
    private TrabajoCola ultimo;
    private int contador = 0;
    
    public void Encolar(String nombreArchivo, int cantidadHojas){
        contador++;
        TrabajoCola nuevaImpresionNodo = new TrabajoCola(contador, nombreArchivo, cantidadHojas);
        
        if (frente == null){
            frente = nuevaImpresionNodo;
            ultimo = nuevaImpresionNodo;
        } else{
            ultimo.punteroSiguiente = nuevaImpresionNodo;
            ultimo = nuevaImpresionNodo;
        }
    }
}
